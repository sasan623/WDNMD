package test5;
//��Ʒ��
public class product {
	private int id;//��Ʒ���
	private String name;//��Ʒ����
	private String msg;//��Ʒ��Ϣ
	private int price;//��Ʒ�۸�
	private String type;//��Ʒ����
	private int quantity;//��Ʒ���
	private String picture;//��ƷͼƬ	
	private int num;//����ͬһ����Ʒ������
	private int totalprice;//����ͬ����Ʒ���ܼ۸�
	public int getTotalprice() {		
		return totalprice;
	}
	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	
		
	
}
